package com.ics499.Project.controller;

import org.springframework.beans.factory.annotation.*;
import org.springframework.web.bind.annotation.*;

import com.ics499.Project.model.*;
import com.ics499.Project.service.*;

@RestController
@RequestMapping("/administrator")
public class AdministratorController {

    @Autowired
    private AdministratorService administratorService;

    @PostMapping("/add")
    public String add(@RequestBody Administrator administrator) {
        administratorService.saveAdministrator(administrator);
        return "New administrator added successfully";
    }

}
