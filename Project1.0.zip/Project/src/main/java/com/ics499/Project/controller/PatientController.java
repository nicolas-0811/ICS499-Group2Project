package com.ics499.Project.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.web.bind.annotation.*;

import com.ics499.Project.model.*;
import com.ics499.Project.service.*;

@RestController
@RequestMapping("/patient")
public class PatientController {

    @Autowired
    private PatientService patientService;

    @PostMapping("/add")
    public String add(@RequestBody Patient patient) {
        patientService.savePatient(patient);
        return "New patient added successfully";
    }

    @GetMapping("/getAll")
    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }
}