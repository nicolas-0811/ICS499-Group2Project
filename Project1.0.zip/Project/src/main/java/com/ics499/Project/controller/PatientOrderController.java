package com.ics499.Project.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.web.bind.annotation.*;

import com.ics499.Project.model.*;
import com.ics499.Project.service.*;

@RestController
@RequestMapping("/patientorder")
public class PatientOrderController {

    @Autowired
    private PatientOrderService patientOrderService;

    @PostMapping("/add")
    public String add(@RequestBody PatientOrder patientOrder) {
        patientOrderService.saveOrder(patientOrder);
        return "New order added successfully";
    }

    @GetMapping("/getAll")
    public List<PatientOrder> getAllOrders() {
        return patientOrderService.getAllOrders();
    }
}