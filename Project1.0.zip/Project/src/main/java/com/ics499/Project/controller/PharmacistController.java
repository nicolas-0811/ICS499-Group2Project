package com.ics499.Project.controller;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.web.bind.annotation.*;

import com.ics499.Project.model.*;
import com.ics499.Project.service.*;

@RestController
@RequestMapping("/pharmacist")
public class PharmacistController {

    @Autowired
    private PharmacistService pharmacistService;

    @PostMapping("/add")
    public String add(@RequestBody Pharmacist pharmacist) {
        pharmacistService.savePharmacist(pharmacist);
        return "New pharmacist added successfully";
    }

    @GetMapping("/getAll")
    public List<Pharmacist> getAllPharmacists() {
        return pharmacistService.getAllPharmacists();
    }
}