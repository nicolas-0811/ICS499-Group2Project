package com.ics499.Project.model;

import javax.persistence.*;

@Entity
public class Administrator {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "admid_generator")
    @SequenceGenerator(name = "admid_generator", initialValue = 100, allocationSize = 1, sequenceName = "admid_seq")
    private int id;
    private String adminName;
    private String email;
    private String password;
    private String birthdate;

    public Administrator() {
    }

    public int getId() {
        return id;
    }

    public void setId(int idPatient) {
        this.id = idPatient;
    }

    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    @Override
    public String toString() {
        return "Administrator: " + adminName + ". ID = " + id;
    }
}