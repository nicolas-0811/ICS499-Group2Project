package com.ics499.Project.model;

import javax.persistence.*;

@Entity
public class Patient {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "patid_generator")
    @SequenceGenerator(name = "patid_generator", initialValue = 10000, allocationSize = 1, sequenceName = "patid_seq")
    private int id;
    private String patientName;
    private String email;
    private String password;
    private String birthdate;
    private String address;
    private String phone;

    public Patient() {
    }

    public int getId() {
        return id;
    }

    public void setId(int idPatient) {
        this.id = idPatient;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

   public String getPhone() {
       return phone;
   }

   public void setPhone(String phone) {
       this.phone = phone;
   }

    @Override
    public String toString() {
        return "Patient: " + patientName + ". ID = " + id;
    }
}