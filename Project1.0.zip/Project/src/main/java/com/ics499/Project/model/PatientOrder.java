package com.ics499.Project.model;

import javax.persistence.*;

@Entity
public class PatientOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "patordid_generator")
    @SequenceGenerator(name = "patordid_generator", initialValue = 20000, allocationSize = 1, sequenceName = "patordid_seq")
    private int id;
    private String patientName;
    private String medication;
    private String dose;
    private String refillDate;
    private String balance;


    public PatientOrder() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getMedication() {
        return medication;
    }

    public void setMedication(String medication) {
        this.medication = medication;
    }

    public String getDose() {
        return dose;
    }

    public void setDose(String dose) {
        this.dose = dose;
    }

    public String getRefillDate() {
        return refillDate;
    }

    public void setRefillDate(String refillDate) {
        this.refillDate = refillDate;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        return "Order for: " + patientName + ". Medication = " + medication + ". Dose = " + dose + ". Prescription ID = " + id;
    }
}