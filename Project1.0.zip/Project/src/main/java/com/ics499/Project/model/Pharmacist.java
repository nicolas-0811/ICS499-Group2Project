package com.ics499.Project.model;

import javax.persistence.*;

@Entity
public class Pharmacist {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "pharid_generator")
    @SequenceGenerator(name = "pharid_generator", initialValue = 1000, allocationSize = 1, sequenceName = "pharid_seq")
    private int id;
    private String pharmacistName;
    private String email;
    private String password;
    private String birthdate;

    public Pharmacist() {
    }

    public int getId() {
        return id;
    }

    public void setId(int idPatient) {
        this.id = idPatient;
    }

    public String getPharmacistName() {
        return pharmacistName;
    }

    public void setPharmacistName(String pharmacistName) {
        this.pharmacistName = pharmacistName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(String birthdate) {
        this.birthdate = birthdate;
    }

    @Override
    public String toString() {
        return "Pharmacist: " + pharmacistName + ". ID = " + id;
    }
}