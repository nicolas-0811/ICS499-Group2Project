package com.ics499.Project.repositories;

import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.*;

import com.ics499.Project.model.*;

@Repository
public interface AdministratorRepository extends JpaRepository<Administrator, Integer> {

}
