package com.ics499.Project.service;

import com.ics499.Project.model.*;

public interface AdministratorService {
    public Administrator saveAdministrator(Administrator administrator);

}
