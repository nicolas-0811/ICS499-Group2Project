package com.ics499.Project.service;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.ics499.Project.model.*;
import com.ics499.Project.repositories.*;

@Service
public class AdministratorServiceImp implements AdministratorService {

    @Autowired
    private AdministratorRepository administratorRepository;

    @Override
    public Administrator saveAdministrator(Administrator administrator) {
        return administratorRepository.save(administrator);
    }
}