package com.ics499.Project.service;

import java.util.*;

import com.ics499.Project.model.*;

public interface PatientOrderService {
    public PatientOrder saveOrder(PatientOrder patientOrder);
    public List<PatientOrder> getAllOrders();

}