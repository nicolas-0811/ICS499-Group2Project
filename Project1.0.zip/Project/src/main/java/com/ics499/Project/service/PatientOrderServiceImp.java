package com.ics499.Project.service;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.ics499.Project.model.*;
import com.ics499.Project.repositories.*;

@Service
public class PatientOrderServiceImp implements PatientOrderService {

    @Autowired
    private PatientOrderRepository patientOrderRepository;

    @Override
    public PatientOrder saveOrder(PatientOrder patientOrder) {
        return patientOrderRepository.save(patientOrder);
    }

    @Override
    public List<PatientOrder> getAllOrders() {
        return patientOrderRepository.findAll();
    }
}