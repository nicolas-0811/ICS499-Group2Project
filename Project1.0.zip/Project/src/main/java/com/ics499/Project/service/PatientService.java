package com.ics499.Project.service;

import java.util.*;

import com.ics499.Project.model.*;

public interface PatientService {
    public Patient savePatient(Patient patient);
    public List<Patient> getAllPatients();

}
