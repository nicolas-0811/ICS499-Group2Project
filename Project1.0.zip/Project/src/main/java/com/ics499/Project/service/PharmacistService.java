package com.ics499.Project.service;

import java.util.*;

import com.ics499.Project.model.*;

public interface PharmacistService {
    public Pharmacist savePharmacist(Pharmacist pharmacist);
    public List<Pharmacist> getAllPharmacists();

}
