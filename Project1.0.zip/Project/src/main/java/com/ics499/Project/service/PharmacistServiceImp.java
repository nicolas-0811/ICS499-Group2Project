package com.ics499.Project.service;

import java.util.*;

import org.springframework.beans.factory.annotation.*;
import org.springframework.stereotype.*;

import com.ics499.Project.model.*;
import com.ics499.Project.repositories.*;

@Service
public class PharmacistServiceImp implements PharmacistService {

    @Autowired
    private PharmacistRepository pharmacistRepository;

    @Override
    public Pharmacist savePharmacist(Pharmacist pharmacist) {
        return pharmacistRepository.save(pharmacist);
    }

    @Override
    public List<Pharmacist> getAllPharmacists() {
        return pharmacistRepository.findAll();
    }
}